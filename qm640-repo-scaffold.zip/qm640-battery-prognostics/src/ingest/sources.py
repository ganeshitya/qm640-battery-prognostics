"""Registry of source archives for the QM640 battery prognostics corpus.

Each entry records where the data lives, how many cells it contributes, and
whether it can be fetched non-interactively. Custodians that serve files behind
an interstitial or session-scoped link are marked ``auto=False``; ``make data``
prints the landing page and the expected destination path for those.
"""

from dataclasses import dataclass, field


@dataclass(frozen=True)
class Source:
    key: str
    name: str
    cells: int
    chemistry: str
    landing_page: str
    dest: str
    auto: bool
    urls: list = field(default_factory=list)
    note: str = ""


SOURCES = [
    Source(
        key="tri_2019",
        name="MIT-Stanford-TRI (Severson et al., 2019)",
        cells=124,
        chemistry="LFP/graphite",
        landing_page="https://data.matr.io/1/",
        dest="data/raw/tri_2019",
        auto=False,
        note=("Three batch .mat files (2017-05-12, 2017-06-30, 2018-04-12). "
              "Processing reference: "
              "https://github.com/rdbraatz/data-driven-prediction-of-battery-cycle-life-before-capacity-degradation"),
    ),
    Source(
        key="tri_2020",
        name="MIT-Stanford-TRI (Attia et al., 2020)",
        cells=45,
        chemistry="LFP/graphite",
        landing_page="https://data.matr.io/1/",
        dest="data/raw/tri_2020",
        auto=False,
        note="Closed-loop optimisation batch; same cell type as tri_2019.",
    ),
    Source(
        key="nasa_pcoe",
        name="NASA PCoE Battery Data Set",
        cells=34,
        chemistry="LCO/NCA",
        landing_page=("https://www.nasa.gov/intelligent-systems-division/"
                      "discovery-and-systems-health/pcoe/pcoe-data-set-repository/"),
        dest="data/raw/nasa_pcoe",
        auto=True,
        urls=["https://phm-datasets.s3.amazonaws.com/NASA/5.+Battery+Data+Set.zip"],
        note="Direct S3 archive; verify against the landing page if the link moves.",
    ),
    Source(
        key="calce",
        name="CALCE, University of Maryland (CS2, CX2)",
        cells=24,
        chemistry="LCO",
        landing_page="https://calce.umd.edu/battery-data",
        dest="data/raw/calce",
        auto=False,
        note="One zip per cell; collect the CS2 and CX2 series.",
    ),
    Source(
        key="oxford",
        name="Oxford Battery Degradation Dataset 1",
        cells=8,
        chemistry="LCO/NCO",
        landing_page="https://ora.ox.ac.uk/objects/uuid:03ba4b01-cfed-46d3-9b1a-7d4a7bdf6fac",
        dest="data/raw/oxford",
        auto=False,
        note="Single .mat of characterisation results, plus ExampleDCC1.mat.",
    ),
]

TOTAL_CELLS = sum(s.cells for s in SOURCES)
